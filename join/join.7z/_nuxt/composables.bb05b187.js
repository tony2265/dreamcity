import{a}from"./entry.07f5324b.js";function s(e,u){return a()._useHead(e,u)}export{s as u};
